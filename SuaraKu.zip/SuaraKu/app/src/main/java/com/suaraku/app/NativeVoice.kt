package com.suaraku.app

object NativeVoice {
    init { System.loadLibrary("suaraku") }
    external fun process(input: DoubleArray, fs: Int, params: DoubleArray): DoubleArray
}
